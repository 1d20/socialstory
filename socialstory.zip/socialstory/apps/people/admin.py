from django.contrib import admin
from models import Friends, FriendsRequests

admin.site.register(Friends)
admin.site.register(FriendsRequests)
