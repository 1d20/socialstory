from django.contrib import admin
from models import FeedbackMessage

admin.site.register(FeedbackMessage)
